﻿using Sandbox.Game.EntityComponents;
using Sandbox.ModAPI.Ingame;
using Sandbox.ModAPI.Interfaces;
using SpaceEngineers.Game.ModAPI.Ingame;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System;
using VRage.Collections;
using VRage.Game.Components;
using VRage.Game.GUI.TextPanel;
using VRage.Game.ModAPI.Ingame.Utilities;
using VRage.Game.ModAPI.Ingame;
using VRage.Game.ObjectBuilders.Definitions;
using VRage.Game;
using VRage;
using VRageMath;

namespace IngameScript
{
    partial class Program : MyGridProgram
    {
        /*
        *   R e a d m e
        *   -----------
        *   
        *   CARGO H-CRANE CONTROLLER
        *   
        *   Allows the control of valid piston-based crane setups from a cockpit using standard ship translation controls.
        *   
        *   The "Call" command moves the crane to its default position to allow boarding and exit of the control cabin.
        */

        // SETTINGS //

        public const string version = "β 1.0.0";

        // RUNTIME VARIABLES //

        private IMyCockpit craneCabin;

        // MAIN FUNCTIONS //

        public Program()
        {
            Runtime.UpdateFrequency = UpdateFrequency.Update10;
        }

        public void Main(string argument, UpdateType updateSource)
        {
            IMyBlockGroup craneBlocks = GridTerminalSystem.GetBlockGroupWithName("Crane");

            if (craneBlocks != null && craneCabin == null)
            {
                List<IMyCockpit> cabins = new List<IMyCockpit>();
                craneBlocks.GetBlocksOfType(cabins);

                foreach (var cabin in cabins)
                {
                    craneCabin = cabin;
                    break;
                }
            }

            if (craneCabin != null)
            {
                List<IMyPistonBase> pistons = new List<IMyPistonBase>();
                craneBlocks.GetBlocksOfType(pistons);

                if (updateSource == UpdateType.Update10)
                {
                    Runtime.UpdateFrequency = craneCabin.IsUnderControl ? UpdateFrequency.Update1 | UpdateFrequency.Update10 : UpdateFrequency.Update10;
                } else if (updateSource == UpdateType.Update1 && craneCabin.IsUnderControl) {
                    foreach (var piston in pistons)
                    {
                        if (piston.CustomName.Contains("X Piston"))
                        {
                            piston.Velocity = (float)ClampVelocity(craneCabin.MoveIndicator.X,piston) * (piston.CustomName.Contains("Inv") ? -1 : 1);
                        } else if (piston.CustomName.Contains("Y Piston")) {
                            piston.Velocity = (float)ClampVelocity(craneCabin.MoveIndicator.Y, piston) * (piston.CustomName.Contains("Inv") ? -1 : 1);
                        } else if (piston.CustomName.Contains("Z Piston")) {
                            piston.Velocity = (float)ClampVelocity(craneCabin.MoveIndicator.Z, piston) * (piston.CustomName.Contains("Inv") ? -1 : 1);
                        }
                    }

                    IMyTextSurface outputMonitor = craneCabin.GetSurface(4);
                    if (outputMonitor != null)
                    {
                        StringBuilder diagOutput = new StringBuilder();
                        diagOutput.Append("#Pistons: ");
                        diagOutput.Append(pistons.Count.ToString());
                        diagOutput.Append("\n");
                        diagOutput.Append(craneCabin.MoveIndicator.ToString());
                        outputMonitor.WriteText(diagOutput, false);
                    }
                } else {
                    foreach (var piston in pistons)
                    {
                        piston.Velocity = 0;
                    }
                }
            }
        }

        private double ClampVelocity(double input,IMyPistonBase referencePiston)
        {
            input = Math.Max(Math.Min(input, referencePiston.MaxVelocity),-referencePiston.MaxVelocity);

            return input;
        }
    }
}

