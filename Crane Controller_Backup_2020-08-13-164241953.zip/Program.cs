﻿using Sandbox.Game.EntityComponents;
using Sandbox.ModAPI.Ingame;
using Sandbox.ModAPI.Interfaces;
using SpaceEngineers.Game.ModAPI.Ingame;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System;
using VRage.Collections;
using VRage.Game.Components;
using VRage.Game.GUI.TextPanel;
using VRage.Game.ModAPI.Ingame.Utilities;
using VRage.Game.ModAPI.Ingame;
using VRage.Game.ObjectBuilders.Definitions;
using VRage.Game;
using VRage;
using VRageMath;

namespace IngameScript
{
    partial class Program : MyGridProgram
    {
        // SETTINGS //

        public const string version = "BETA v1.2.0";

        // RUNTIME VARIABLES //

        private bool callOverride = false;
        private IMyCockpit craneCabin;
        private StringBuilder diagOutput = new StringBuilder();
        private IMyTextSurface outputMonitor;

        // MAIN FUNCTIONS //

        public Program()
        {
            Runtime.UpdateFrequency = UpdateFrequency.Update100;
        }

        public void Main(string argument, UpdateType updateSource)
        {
            // Wipe the previously built string and rebuild the crane block group.
            diagOutput.Length = 0;
            IMyBlockGroup craneBlocks = GridTerminalSystem.GetBlockGroupWithName("Crane");

            if (craneBlocks != null && craneCabin == null)
            {
                List<IMyCockpit> cabins = new List<IMyCockpit>();
                craneBlocks.GetBlocksOfType(cabins);

                foreach (var cabin in cabins) {
                    craneCabin = cabin;
                    outputMonitor = cabin.GetSurface(4);
                    break;
                }
            }

            if (craneCabin != null) {
                if (!string.IsNullOrEmpty(argument) && argument == "Call") {
                    callOverride = true;

                    List<IMyShipConnector> connectors = new List<IMyShipConnector>();
                    craneBlocks.GetBlocksOfType(connectors);

                    foreach (var connector in connectors) {
//                        connector.Disconnect();
                        connector.Enabled = false;
                    }
                }

                List<IMyInteriorLight> lights = new List<IMyInteriorLight>();
                craneBlocks.GetBlocksOfType(lights);

                foreach (var light in lights) {
                    light.Enabled = craneCabin.IsUnderControl;
                }

                List<IMyPistonBase> pistons = new List<IMyPistonBase>();
                craneBlocks.GetBlocksOfType(pistons);

                diagOutput.Append("CRANE FIRMWARE ");
                diagOutput.Append(version);
                diagOutput.Append("\n");

                if (!callOverride) {
                    if (updateSource == UpdateType.Update100) {
                        Runtime.UpdateFrequency = craneCabin.IsUnderControl ? UpdateFrequency.Update1 | UpdateFrequency.Update100 : UpdateFrequency.Update100;
                    } else if (updateSource == UpdateType.Update1 && craneCabin.IsUnderControl) {
                        foreach (var piston in pistons) {
                            // Update piston velocities based on the translation inputs the crane cabin is receiving from the user and which axes the pistons move on.
                            if (piston.CustomName.Contains("X Piston")) {
                                piston.Velocity = (float)ClampVelocity(craneCabin.MoveIndicator.X, piston) * (piston.CustomName.Contains("Inv") ? -1 : 1);
                            } else if (piston.CustomName.Contains("Y Piston")) {
                                piston.Velocity = (float)ClampVelocity(craneCabin.MoveIndicator.Y, piston) * (piston.CustomName.Contains("Inv") ? -1 : 1);
                            } else if (piston.CustomName.Contains("Z Piston")) {
                                piston.Velocity = (float)ClampVelocity(craneCabin.MoveIndicator.Z, piston) * (piston.CustomName.Contains("Inv") ? -1 : 1);
                            }
                        }

                        if (outputMonitor != null) {
                            diagOutput.Append(craneCabin.MoveIndicator.ToString());
                            outputMonitor.WriteText(diagOutput, false);
                        }
                    } else {
                        foreach (var piston in pistons) {
                            piston.Velocity = 0;
                        }
                    }
                } else {
                    foreach (var piston in pistons) {
                        if (piston.CustomName.Contains("X Piston")) {
                            piston.Velocity = piston.CustomName.Contains("Inv") ? -1 : 1;
                        } else if (piston.CustomName.Contains("Y Piston")) {
                            piston.Velocity = piston.CustomName.Contains("Inv") ? -1 : 1;
                        } else if (piston.CustomName.Contains("Z Piston")) {
                            piston.Velocity = piston.CustomName.Contains("Inv") ? 1 : -1;
                        }
                    }

                    if (outputMonitor != null) {
                        diagOutput.Append("CALL OVERRIDE; PLEASE WAIT.");
                        outputMonitor.WriteText(diagOutput, false);
                    }

                    // Check how many of the pistons have finished their journeys. If they've all reached their limits, end the lockout.
                    int completedPistons = 0;
                    foreach (var piston in pistons) {
                        if ((piston.Velocity > 0 && piston.CurrentPosition >= piston.MaxLimit - 0.05) || (piston.Velocity < 0 && piston.CurrentPosition <= piston.MinLimit + 0.05)) {
                            completedPistons++;
                        }
                    }

                    callOverride = !(completedPistons == pistons.Count);

                    if (!callOverride) {
                        List<IMyShipConnector> connectors = new List<IMyShipConnector>();
                        craneBlocks.GetBlocksOfType(connectors);

                        foreach (var connector in connectors) {
                            connector.Enabled = true;
                        }
                    }
                }
            }
        }

        private double ClampVelocity(double input,IMyPistonBase referencePiston)
        {
            input = Math.Max(Math.Min(input, referencePiston.MaxVelocity),-referencePiston.MaxVelocity);

            return input;
        }
    }
}

